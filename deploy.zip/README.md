# dicom-extractor
dicom file extractor function for AWS lambda
